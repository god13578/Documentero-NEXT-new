export default function Dashboard() {
  return <h1>ระบบเอกสารราชการ</h1>;
}
