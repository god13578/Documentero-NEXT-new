export default function Test(){
  return (
    <div className="p-10 bg-blue-500 text-white text-3xl">
      Tailwind OK!
    </div>
  );
}
